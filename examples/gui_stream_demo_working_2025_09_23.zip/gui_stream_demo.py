﻿import math
import pathlib
import queue
import threading
import time
import sys
import textwrap
from collections import deque
from typing import Deque, Dict, Iterable, List, Optional, Tuple

import numpy as np
import tkinter as tk
from tkinter import messagebox, ttk

PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:
    from muse_py import Muse, MuseConfigurationInfo
except Exception as exc:  # pragma: no cover
    Muse = None
    MuseConfigurationInfo = None
    _import_error = exc
else:
    _import_error = None

EEG_LABELS_BY_COUNT: Dict[int, List[str]] = {
    4: ["TP9", "AF7", "AF8", "TP10"],
    5: ["TP9", "AF7", "AF8", "TP10", "POz"],
    6: ["TP9", "AF7", "AF8", "TP10", "POz", "AUX1"],
}
MODEL_SPECIFIC_EEG: Dict[str, List[str]] = {
    "Muse 2014 (MU-01)": ["TP9", "AF7", "AF8", "TP10"],
    "Muse 2016 (MU-02)": ["TP9", "AF7", "AF8", "TP10", "POz"],
    "Muse 2 (MU-03)": ["TP9", "AF7", "AF8", "TP10"],
    "Muse S 2019 (MU-04)": ["TP9", "AF7", "AF8", "TP10", "POz"],
    "Muse S 2021 (MU-05)": ["TP9", "AF7", "AF8", "TP10", "POz"],
    "Muse 2 2024 (MU-06)": ["TP9", "AF7", "AF8", "TP10", "POz"],
    "Muse S 2025 (MS-03)": ["TP9", "AF7", "AF8", "TP10", "POz", "AUX1"],
}
OPTICS_LABELS = [
    "Optics1", "Optics2", "Optics3", "Optics4",
    "Optics5", "Optics6", "Optics7", "Optics8",
    "Optics9", "Optics10", "Optics11", "Optics12",
    "Optics13", "Optics14", "Optics15", "Optics16",
]
DEFAULT_CHANNEL_LABELS: Dict[str, List[str]] = {
    "ACC": ["X", "Y", "Z"],
    "GYRO": ["X", "Y", "Z"],
    "PPG": ["PPG1", "PPG2", "PPG3"],
    "DRL_REF": ["DRL", "REF"],
    "BATTERY": [
        "% remaining", "millivolts", "temp C", "avg current uA",
        "time to empty s", "time to full s", "capacity mAh",
        "remaining mAh", "age %", "cycles",
    ],
}
PACKET_UNITS: Dict[str, str] = {
    "EEG": "uV",
    "OPTICS": "uA",
    "ACC": "g",
    "GYRO": "deg/s",
    "PPG": "a.u.",
    "BATTERY": "",
    "DRL_REF": "uV",
}

EEG_COLORS = ["#00ff99", "#33cfff", "#ff6b6b", "#ffa94d", "#b197fc", "#12b886"]
OPTICS_COLORS = [
    "#ff922b", "#f783ac", "#94d82d", "#4dabf7",
    "#9775fa", "#ff8787", "#63e6be", "#ffd43b",
    "#a9e34b", "#22b8cf", "#e599f7", "#ffc078",
    "#74c0fc", "#fab005", "#ff4d6d", "#2ec4b6",
]
HISTORY_LENGTHS: Dict[str, int] = {
    "EEG": 512,
    "OPTICS": 512,
    "PPG": 512,
    "ACC": 256,
    "GYRO": 256,
    "BATTERY": 64,
    "DRL_REF": 128,
}

SPECTRUM_MAX_FRAMES = 120
SPECTRUM_DISPLAY_MAX_HZ = 70.0

PRESET_SUMMARIES: Dict[str, str] = {
    "20": "Muse 2016 research preset (5 EEG channels, 12-bit, 256 Hz).",
    "21": "Default EEG streaming (Muse 2 / Muse S): 4 EEG channels @ 256 Hz with motion sensors enabled.",
    "1031": "EEG + optics with low LED intensity (battery friendly).",
    "1032": "EEG + optics with medium LED intensity.",
    "1033": "EEG + optics with high LED intensity.",
    "1034": "EEG + expanded optics developer preset (Muse Athena).",
    "1035": "EEG + optics commonly used on Muse S / Muse S 2025 (four optical pairs).",
    "1036": "EEG + full optics array (up to 16 channels on Muse Athena).",
}

PRESET_HELP_TEXT = textwrap.dedent("""\
Preset overview
---------------
20   - Legacy Muse 2016 research preset (5 EEG channels).
21   - Default EEG streaming for Muse 2 / Muse S (4 EEG channels @ 256 Hz).
1031 - EEG + optics with low LED intensity (conserves battery).
1032 - EEG + optics with medium LED intensity.
1033 - EEG + optics with high LED intensity.
1034 - EEG + expanded optics developer preset (Muse Athena).
1035 - EEG + optics commonly used on Muse S / Muse S 2025 (four optical pairs).
1036 - EEG + full optics array (up to 16 channels on Muse Athena).

Tip: Start with the default for your headset (21 for EEG-only, 1035 for Muse S optics, 1036 for Muse Athena) and
only change if you need different optics power or channel counts.
""")

class MuseApp:
    PACKET_ORDER = ("EEG", "OPTICS", "PPG", "ACC", "GYRO", "BATTERY", "DRL_REF")

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Muse Wrapper Showcase")
        self.root.geometry("1120x690")

        self.muse: Optional[Muse] = None
        self.devices: List = []
        self.connected = False

        self.data_queue: queue.Queue = queue.Queue(maxsize=2048)
        self.event_queue: queue.Queue = queue.Queue()

        self.latest_values: Dict[str, Tuple[int, List[float]]] = {}
        self.sample_windows: Dict[str, Deque[float]] = {
            pkt: deque(maxlen=512) for pkt in self.PACKET_ORDER
        }
        self.channel_buffers: Dict[str, List[Deque[float]]] = {}
        self.config: Optional[MuseConfigurationInfo] = None
        self.connection_state = "DISCONNECTED"
        self.eeg_sample_rate = 256.0
        self.eeg_buffers: List[Deque[float]] = []
        self.spectrum_frames: Deque[np.ndarray] = deque(maxlen=SPECTRUM_MAX_FRAMES)
        self.spectrum_freqs: Optional[np.ndarray] = None
        self._spectrum_window_seconds = 0.0
        self._spectrum_fft_size = 256

        self.eeg_display_range = 200.0
        self.optics_display_range = 1000.0

        self.spectrum_status_var: Optional[tk.StringVar] = None
        self._eeg_scale_presets = [1, 10, 50, 100, 200, 500, 1000]
        self._optics_scale_presets = [100, 250, 500, 1000, 2000]
        self.detrend_var = tk.BooleanVar(master=self.root, value=True)
        self.eeg_scale_combo: Optional[ttk.Combobox] = None
        self.optics_scale_combo: Optional[ttk.Combobox] = None
        self._waveform_job: Optional[str] = None
        self.preset_hint_var: Optional[tk.StringVar] = None

        self._build_ui()

        if Muse is None:
            messagebox.showerror(
                "Muse wrapper missing",
                "Couldn't import muse_py. Build it via CMake.\n" + f"Original error: {_import_error!r}"
            )
        else:
            try:
                self.muse = Muse()
            except Exception as exc:
                messagebox.showerror("Muse init failed", str(exc))

        self.root.after(150, self._process_events)
        self._queue_waveform_refresh(250)

    # ---------------------- UI setup ---------------------------
    def _build_ui(self) -> None:
        main = ttk.Frame(self.root, padding=10)
        main.pack(fill=tk.BOTH, expand=True)

        controls = ttk.LabelFrame(main, text="Discovery & Connection")
        controls.pack(fill=tk.X)

        ttk.Button(controls, text="Scan", command=self._scan_devices).grid(row=0, column=0, padx=4, pady=4)
        ttk.Label(controls, text="Preset:").grid(row=0, column=1, padx=(12, 4))
        self.preset_var = tk.StringVar(value="21")
        self.preset_combo = ttk.Combobox(
            controls,
            textvariable=self.preset_var,
            values=("21", "20", "1031", "1032", "1033", "1034", "1035", "1036"),
            state="readonly",
            width=10,
        )
        self.preset_combo.grid(row=0, column=2, pady=4)
        self.preset_combo.bind("<<ComboboxSelected>>", self._on_preset_changed)
        ttk.Button(controls, text="Connect", command=self._connect).grid(row=0, column=3, padx=4)
        ttk.Button(controls, text="Disconnect", command=self._disconnect).grid(row=0, column=4, padx=4)
        ttk.Button(controls, text="Refresh Config", command=self._request_configuration).grid(row=0, column=5, padx=6)
        ttk.Button(controls, text="Preset help", command=self._show_preset_help).grid(row=0, column=6, padx=6)
        controls.columnconfigure(7, weight=1)

        self.preset_hint_var = tk.StringVar(value=self._preset_summary(self.preset_var.get()))
        ttk.Label(main, textvariable=self.preset_hint_var, foreground="#666666", wraplength=760).pack(fill=tk.X, pady=(4, 2))

        device_frame = ttk.Frame(main)
        device_frame.pack(fill=tk.X, pady=(6, 0))
        ttk.Label(device_frame, text="Discovered headsets:").pack(anchor=tk.W)
        self.device_list = tk.Listbox(device_frame, height=5, exportselection=False)
        self.device_list.pack(fill=tk.X)

        self.status_var = tk.StringVar(value="Idle. Click Scan to discover headsets.")
        ttk.Label(main, textvariable=self.status_var).pack(fill=tk.X, pady=(6, 10))

        notebook = ttk.Notebook(main)
        notebook.pack(fill=tk.BOTH, expand=True)

        self.summary_tab = ttk.Frame(notebook)
        self.metrics_tab = ttk.Frame(notebook)
        self.wave_tab = ttk.Frame(notebook)
        self.spectrum_tab = ttk.Frame(notebook)
        notebook.add(self.summary_tab, text="Summary")
        notebook.add(self.metrics_tab, text="Channel Metrics")
        notebook.add(self.wave_tab, text="Live Waveforms & Log")
        notebook.add(self.spectrum_tab, text="Power Spectrum")


        self._build_summary_tab()
        self._build_metrics_tab()
        self._build_wave_tab()
        self._build_spectrum_tab()

    def _build_summary_tab(self) -> None:
        left = ttk.Frame(self.summary_tab, padding=8)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.connection_state_var = tk.StringVar(value="DISCONNECTED")
        ttk.Label(left, text="Connection state:").grid(row=0, column=0, sticky=tk.W)
        ttk.Label(
            left,
            textvariable=self.connection_state_var,
            font=("Segoe UI", 11, "bold"),
            foreground="#1c7ed6",
        ).grid(row=0, column=1, sticky=tk.W)

        self.model_var = tk.StringVar(value="<N/A>")
        self.preset_summary_var = tk.StringVar(value="<N/A>")
        self.eeg_rate_var = tk.StringVar(value="<unknown>")
        self.optics_rate_var = tk.StringVar(value="<unknown>")
        self.acc_rate_var = tk.StringVar(value="<unknown>")
        self.battery_var = tk.StringVar(value="<unknown>")
        self.notch_var = tk.StringVar(value="<unknown>")

        stats = (
            ("Model", self.model_var),
            ("Preset", self.preset_summary_var),
            ("EEG rate", self.eeg_rate_var),
            ("Optics rate", self.optics_rate_var),
            ("ACC rate", self.acc_rate_var),
            ("Notch filter", self.notch_var),
            ("Battery", self.battery_var),
        )
        for idx, (label, var) in enumerate(stats, start=1):
            ttk.Label(left, text=f"{label}:").grid(row=idx, column=0, sticky=tk.W, pady=2)
            ttk.Label(left, textvariable=var).grid(row=idx, column=1, sticky=tk.W, pady=2)

        right = ttk.LabelFrame(self.summary_tab, text="Configuration snapshot", padding=8)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0))
        self.cfg_text = tk.Text(right, height=16, wrap=tk.WORD, bg="#f5f5f5", relief=tk.FLAT)
        self.cfg_text.pack(fill=tk.BOTH, expand=True)
        self.cfg_text.configure(state=tk.DISABLED)

    def _build_metrics_tab(self) -> None:
        frame = ttk.Frame(self.metrics_tab, padding=8)
        frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(frame, text="Per-packet summary").pack(anchor=tk.W)
        self.packet_tree = ttk.Treeview(
            frame,
            columns=("rate", "channels", "description"),
            show="headings",
            height=10,
        )
        self.packet_tree.heading("rate", text="Packets/s")
        self.packet_tree.heading("channels", text="Channels")
        self.packet_tree.heading("description", text="Description")
        self.packet_tree.column("rate", width=90, anchor=tk.CENTER)
        self.packet_tree.column("channels", width=140)
        self.packet_tree.column("description", width=420)
        self.packet_tree.pack(fill=tk.BOTH, expand=True)
        self.packet_rows: Dict[str, str] = {}
        descriptions = {
            "EEG": "Raw EEG stream",
            "OPTICS": "Optics/fNIRS diodes",
            "PPG": "PPG sensors",
            "ACC": "Accelerometer",
            "GYRO": "Gyroscope",
            "BATTERY": "Battery telemetry",
            "DRL_REF": "DRL / reference",
        }
        for pkt in self.PACKET_ORDER:
            row = self.packet_tree.insert("", tk.END, values=("0.00", "--", descriptions.get(pkt, "")))
            self.packet_rows[pkt] = row

        ttk.Label(frame, text="Latest channel values").pack(anchor=tk.W, pady=(10, 0))
        self.channel_tree = ttk.Treeview(
            frame,
            columns=("packet", "channel", "value"),
            show="headings",
            height=12,
        )
        self.channel_tree.heading("packet", text="Packet")
        self.channel_tree.heading("channel", text="Channel")
        self.channel_tree.heading("value", text="Latest")
        self.channel_tree.column("packet", width=110)
        self.channel_tree.column("channel", width=150)
        self.channel_tree.column("value", width=160)
        self.channel_tree.pack(fill=tk.BOTH, expand=True, pady=(0, 8))

    def _build_wave_tab(self) -> None:
        top = ttk.Frame(self.wave_tab)
        top.pack(fill=tk.BOTH, expand=True)

        control = ttk.LabelFrame(top, text="Waveform scale", padding=(8, 4))
        control.pack(fill=tk.X, padx=8, pady=(8, 4))

        ttk.Label(control, text="EEG +/- (uV)").grid(row=0, column=0, sticky=tk.W)
        self.eeg_scale_combo = ttk.Combobox(
            control,
            values=[str(v) for v in self._eeg_scale_presets],
            state="readonly",
            width=8,
        )
        self.eeg_scale_combo.set(str(int(self.eeg_display_range)))
        self.eeg_scale_combo.grid(row=0, column=1, padx=(4, 12))
        self.eeg_scale_combo.bind("<<ComboboxSelected>>", self._handle_scale_change)

        ttk.Label(control, text="Optics +/- (uA)").grid(row=0, column=2, sticky=tk.W, padx=(12, 0))
        self.optics_scale_combo = ttk.Combobox(
            control,
            values=[str(v) for v in self._optics_scale_presets],
            state="readonly",
            width=8,
        )
        self.optics_scale_combo.set(str(int(self.optics_display_range)))
        self.optics_scale_combo.grid(row=0, column=3, padx=(4, 12))
        self.optics_scale_combo.bind("<<ComboboxSelected>>", self._handle_scale_change)

        ttk.Button(control, text="Auto scale", command=self._auto_scale_waveforms).grid(row=0, column=4, padx=(4, 12))
        ttk.Button(control, text="Reset", command=self._reset_scale).grid(row=0, column=5, padx=(0, 12))
        ttk.Checkbutton(
            control,
            text="Subtract DC offset",
            variable=self.detrend_var,
            command=lambda: self._queue_waveform_refresh(0),
        ).grid(row=0, column=6, sticky=tk.W)

        control.columnconfigure(7, weight=1)
        self._handle_scale_change()

        self.eeg_canvas = tk.Canvas(top, height=220, bg="#101010")
        self.eeg_canvas.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 4))
        self.eeg_canvas.create_text(
            10,
            10,
            anchor=tk.NW,
            fill="#cccccc",
            text="EEG (uV)",
            font=("Segoe UI", 10, "bold"),
            tags="static",
        )

        self.optics_canvas = tk.Canvas(top, height=200, bg="#151515")
        self.optics_canvas.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        self.optics_canvas.create_text(
            10,
            10,
            anchor=tk.NW,
            fill="#dddddd",
            text="Optics (uA)",
            font=("Segoe UI", 10, "bold"),
            tags="static",
        )

        log_frame = ttk.LabelFrame(self.wave_tab, text="Event log", padding=6)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        self.log_text = tk.Text(log_frame, height=8, bg="#f0f0f0", wrap=tk.WORD, state=tk.DISABLED)
        self.log_text.pack(fill=tk.BOTH, expand=True)

    def _build_spectrum_tab(self) -> None:
        frame = ttk.Frame(self.spectrum_tab, padding=8)
        frame.pack(fill=tk.BOTH, expand=True)

        controls = ttk.Frame(frame)
        controls.pack(fill=tk.X, pady=(0, 8))
        reset_btn = ttk.Button(
            controls,
            text="Reset Averaging",
            command=lambda: self._reset_spectrum("Averaging reset. Waiting for data..."),
        )
        reset_btn.pack(side=tk.LEFT)
        if self.spectrum_status_var is None:
            self.spectrum_status_var = tk.StringVar(value="Waiting for data...")
        else:
            self.spectrum_status_var.set("Waiting for data...")
        ttk.Label(controls, textvariable=self.spectrum_status_var, foreground="#666666").pack(side=tk.LEFT, padx=(8, 0))

        self.spectrum_canvas = tk.Canvas(frame, height=360, bg="#181818")
        self.spectrum_canvas.pack(fill=tk.BOTH, expand=True)
        self.spectrum_canvas.create_text(
            10,
            10,
            anchor=tk.NW,
            fill="#dddddd",
            text="Averaged EEG power spectrum (0-70 Hz)",
            font=("Segoe UI", 10, "bold"),
            tags="static",
        )
        self._reset_spectrum()

    # --------------------- helpers ------------------------------
    def _scan_devices(self) -> None:
        if self.muse is None:
            return
        self.status_var.set("Scanning for Muse devices...")
        self.device_list.delete(0, tk.END)

        def worker() -> None:
            try:
                devices = self.muse.list_devices()
            except Exception as exc:
                self.event_queue.put(("error", f"Scan failed: {exc}"))
                return
            self.event_queue.put(("devices", devices))
            self.event_queue.put(("status", f"Found {len(devices)} device(s)."))
            self.event_queue.put(("event", f"Scan complete: {len(devices)} device(s)"))

        threading.Thread(target=worker, daemon=True).start()

    def _connect(self) -> None:
        if self.muse is None:
            return
        if self.connected:
            self.status_var.set("Already connected.")
            return
        selection = self.device_list.curselection()
        if not selection:
            messagebox.showinfo("Select a device", "Pick a headset from the list first.")
            return
        index = selection[0]
        preset = self.preset_var.get()
        self.status_var.set("Connecting...")

        def worker() -> None:
            try:
                self.muse.connect(index, self._on_data, preset=preset, on_state=self._on_state)
            except Exception as exc:
                self.event_queue.put(("error", f"Connect failed: {exc}"))
                return
            self.connected = True
            info = self.devices[index]
            msg = f"Connected to {info.name} ({info.mac}) preset {preset}"
            self.event_queue.put(("status", msg))
            self.event_queue.put(("event", msg))
            self.event_queue.put(("state", "CONNECTED"))
            self._kickoff_config_poll()

        threading.Thread(target=worker, daemon=True).start()

    def _disconnect(self) -> None:
        if self.muse is None or not self.connected:
            return
        try:
            self.muse.disconnect()
        except Exception as exc:
            self.event_queue.put(("error", f"Disconnect failed: {exc}"))
        finally:
            self.connected = False
            self.config = None
            self.channel_buffers.clear()
            self.latest_values.clear()
            self._reset_spectrum()
            self.connection_state = "DISCONNECTED"
            self.connection_state_var.set("DISCONNECTED")
            self._update_summary()
            self.event_queue.put(("status", "Disconnected."))
            self.event_queue.put(("event", "Disconnected."))

    def _kickoff_config_poll(self) -> None:
        if self.muse is None:
            return

        def poller() -> None:
            for _ in range(30):
                cfg = None
                try:
                    cfg = self.muse.get_configuration()
                except Exception:
                    cfg = None
                if cfg is not None:
                    self.event_queue.put(("config", cfg))
                    return
                time.sleep(0.3)

        threading.Thread(target=poller, daemon=True).start()

    def _request_configuration(self) -> None:
        if self.muse is None or not self.connected:
            return
        self._kickoff_config_poll()

    # ------------------- callbacks ------------------------------
    def _on_data(self, packet_type: str, timestamp: int, values: list) -> None:
        if not values:
            return
        now = time.time()
        self.sample_windows.setdefault(packet_type, deque(maxlen=512)).append(now)
        trimmed = [float(v) for v in values]
        try:
            self.data_queue.put_nowait((packet_type, timestamp, trimmed))
        except queue.Full:
            try:
                self.data_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self.data_queue.put_nowait((packet_type, timestamp, trimmed))
            except queue.Full:
                pass

    def _on_state(self, state: str) -> None:
        self.event_queue.put(("event", f"State change: {state}"))
        self.event_queue.put(("state", state))

    # ------------------- event loop ------------------------------
    def _process_events(self) -> None:
        while True:
            try:
                kind, payload = self.event_queue.get_nowait()
            except queue.Empty:
                break

            if kind == "devices":
                self.devices = payload  # type: ignore[assignment]
                self.device_list.delete(0, tk.END)
                for idx, dev in enumerate(self.devices):
                    self.device_list.insert(tk.END, f"{idx}: {dev.name} ({dev.mac})")
            elif kind == "status":
                self.status_var.set(str(payload))
            elif kind == "error":
                messagebox.showerror("Muse error", str(payload))
                self._append_log(f"Error: {payload}")
            elif kind == "event":
                self._append_log(str(payload))
            elif kind == "state":
                state = str(payload)
                self.connection_state = state
                self.connection_state_var.set(state)
                if "CONNECTED" in state:
                    self.connected = True
                if state.startswith("DISCONNECTED"):
                    self.connected = False
            elif kind == "config":
                self.config = payload  # type: ignore[assignment]
                self._update_from_config()
                self._append_log("Configuration updated from device.")
                self._update_summary()

        new_packets: List[Tuple[str, int, List[float]]] = []
        eeg_updated = False
        while True:
            try:
                new_packets.append(self.data_queue.get_nowait())
            except queue.Empty:
                break

        for packet_type, timestamp, values in new_packets:
            numeric_values = [float(v) for v in values]
            if packet_type == "EEG":
                eeg_updated = True
            self.latest_values[packet_type] = (timestamp, numeric_values)
            self._ensure_channel_buffers(packet_type, len(numeric_values))
            buffers = self.channel_buffers[packet_type]
            for buf, val in zip(buffers, numeric_values):
                buf.append(val)
            self._update_channel_table(packet_type, timestamp, numeric_values)
        if new_packets:
            self._update_metrics()
            self._update_summary()
            if eeg_updated:
                self._update_spectrum_data()

        self.root.after(150, self._process_events)

    # ------------------- data helpers ---------------------------
    def _update_from_config(self) -> None:
        cfg = self.config
        if cfg is None:
            return
        sr = float(getattr(cfg, "output_frequency", 0) or 0)
        if sr:
            self.eeg_sample_rate = sr

    def _ensure_channel_buffers(self, packet_type: str, count: int) -> None:
        buffers = self.channel_buffers.setdefault(packet_type, [])
        history = HISTORY_LENGTHS.get(packet_type, 256)
        current = len(buffers)
        if current == count:
            return
        if current > count:
            del buffers[count:]
            return
        for _ in range(count - current):
            buffers.append(deque(maxlen=history))

    def _packet_rate(self, packet_type: str) -> float:
        window = self.sample_windows.get(packet_type)
        if not window or len(window) < 2:
            return 0.0
        span = window[-1] - window[0]
        if span <= 0:
            return 0.0
        return len(window) / span

    def _channel_labels(self, packet_type: str, count: int) -> List[str]:
        if packet_type == "EEG":
            if self.config is not None:
                labels = MODEL_SPECIFIC_EEG.get(getattr(self.config, "model", ""))
                if labels and len(labels) >= count:
                    return labels[:count]
            return EEG_LABELS_BY_COUNT.get(count, [f"EEG{i + 1}" for i in range(count)])
        if packet_type == "OPTICS":
            return OPTICS_LABELS[:count]
        base = DEFAULT_CHANNEL_LABELS.get(packet_type)
        if base:
            return base[:count]
        return [f"{packet_type}{i + 1}" for i in range(count)]

    def _update_metrics(self) -> None:
        for pkt in self.PACKET_ORDER:
            row = self.packet_rows[pkt]
            rate = self._packet_rate(pkt)
            channels = len(self.latest_values[pkt][1]) if pkt in self.latest_values else 0
            description = self.packet_tree.item(row, "values")[2]
            self.packet_tree.item(row, values=(f"{rate:.2f}", channels, description))

    def _update_channel_table(self, packet_type: str, timestamp: int, values: List[float]) -> None:
        # rebuild table each time
        self.channel_tree.delete(*self.channel_tree.get_children())
        for pkt in self.PACKET_ORDER:
            entry = self.latest_values.get(pkt)
            if not entry:
                continue
            _, vals = entry
            labels = self._channel_labels(pkt, len(vals))
            unit = PACKET_UNITS.get(pkt, "")
            for label, val in zip(labels, vals):
                formatted = f"{val:.3f}" if abs(val) < 1e6 else f"{val:.3e}"
                if unit:
                    formatted = f"{formatted} {unit}"
                self.channel_tree.insert("", tk.END, values=(pkt, label, formatted))

    def _append_log(self, message: str) -> None:
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state=tk.DISABLED)

    def _preset_summary(self, preset: str) -> str:
        info = PRESET_SUMMARIES.get(preset)
        if info:
            return f"{preset}: {info}"
        return f"Preset {preset}: see preset help for details."

    def _on_preset_changed(self, _event=None) -> None:
        if self.preset_hint_var is not None:
            self.preset_hint_var.set(self._preset_summary(self.preset_var.get()))

    def _show_preset_help(self) -> None:
        top = tk.Toplevel(self.root)
        top.title("Muse presets")
        top.resizable(False, False)
        frame = ttk.Frame(top, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        text = tk.Text(frame, width=80, height=18, wrap=tk.WORD, bg="#fdfdfd")
        text.insert(tk.END, PRESET_HELP_TEXT)
        text.configure(state=tk.DISABLED)
        text.pack(fill=tk.BOTH, expand=True)
        ttk.Button(frame, text="Close", command=top.destroy).pack(pady=(6, 0))

    def _update_summary(self) -> None:
        cfg = self.config
        if cfg is None:
            self.model_var.set("<N/A>")
            self.preset_summary_var.set(self.preset_var.get())
            if self.preset_hint_var is not None:
                self.preset_hint_var.set(self._preset_summary(self.preset_var.get()))
            self.eeg_rate_var.set("<unknown>")
            self.optics_rate_var.set("<unknown>")
            self.acc_rate_var.set("<unknown>")
            self.battery_var.set("<unknown>")
            self.notch_var.set("<unknown>")
        else:
            self.model_var.set(getattr(cfg, "model", "<unknown>"))
            preset = getattr(cfg, "preset", self.preset_var.get())
            self.preset_summary_var.set(self._preset_summary(str(preset)))
            self.eeg_rate_var.set(f"{getattr(cfg, 'output_frequency', 0)} Hz")
            optics_rate = getattr(cfg, 'downsample_rate', None)
            self.optics_rate_var.set(f"{optics_rate} Hz" if optics_rate else "<unknown>")
            acc_rate = getattr(cfg, 'accelerometer_sample_frequency', None)
            self.acc_rate_var.set(f"{acc_rate} Hz" if acc_rate else "<unknown>")
            notch_enabled = getattr(cfg, 'notch_filter_enabled', None)
            notch = getattr(cfg, 'notch_filter', None)
            self.notch_var.set(f"{notch} ({'on' if notch_enabled else 'off'})" if notch is not None else "<unknown>")
            battery = getattr(cfg, 'battery_percent_remaining', None)
            if battery is not None:
                self.battery_var.set(f"{battery:.1f}%")
            else:
                self.battery_var.set("<unknown>")
            if self.preset_hint_var is not None:
                self.preset_hint_var.set(self._preset_summary(str(preset)))
        self._update_config_text()

    def _update_config_text(self) -> None:
        self.cfg_text.configure(state=tk.NORMAL)
        self.cfg_text.delete("1.0", tk.END)
        cfg = self.config
        if cfg is None:
            text = "<No configuration captured yet. Click Refresh Config after connecting>."
        else:
            fields = [
                "preset", "model", "headband_name", "bluetooth_mac", "serial_number",
                "headset_serial_number", "microcontroller_id", "eeg_channel_count",
                "output_frequency", "downsample_rate", "accelerometer_sample_frequency",
                "drl_ref_frequency", "battery_data_enabled", "drl_ref_enabled",
                "notch_filter", "notch_filter_enabled", "afe_gain", "serout_mode",
                "adc_frequency", "battery_percent_remaining",
            ]
            lines = ["MuseConfigurationInfo:"]
            for field in fields:
                lines.append(f"  {field}: {getattr(cfg, field, None)}")
            text = "\n".join(lines)
        self.cfg_text.insert(tk.END, text)
        self.cfg_text.configure(state=tk.DISABLED)

    def _reset_scale(self) -> None:
        self.eeg_display_range = 200.0
        self.optics_display_range = 1000.0
        self.eeg_scale_combo.set("200")
        self.optics_scale_combo.set("1000")
        self._handle_scale_change()

    def _current_eeg_range(self) -> float:
        return float(self.eeg_display_range)

    def _current_optics_range(self) -> float:
        return float(self.optics_display_range)

    def _update_scale_from_ui(self) -> None:
        try:
            self.eeg_display_range = max(1.0, float(self.eeg_scale_combo.get()))
        except Exception:
            pass
        try:
            self.optics_display_range = max(1.0, float(self.optics_scale_combo.get()))
        except Exception:
            pass

    def _handle_scale_change(self, *_: object) -> None:
        self._update_scale_from_ui()
        self._queue_waveform_refresh(0)


    def _auto_scale_waveforms(self) -> None:
        changed = False
        eeg_buffers = self.channel_buffers.get("EEG")
        if eeg_buffers:
            suggested = self._suggest_scale(eeg_buffers, self._eeg_scale_presets)
            if suggested is not None:
                self.eeg_scale_combo.set(str(int(suggested)))
                changed = True
        optics_buffers = self.channel_buffers.get("OPTICS")
        if optics_buffers:
            suggested_optics = self._suggest_scale(optics_buffers, self._optics_scale_presets)
            if suggested_optics is not None:
                self.optics_scale_combo.set(str(int(suggested_optics)))
                changed = True
        if changed:
            self._handle_scale_change()

    def _suggest_scale(self, buffers: List[Deque[float]], presets: List[int], margin: float = 1.3) -> Optional[float]:
        samples: List[float] = []
        for buf in buffers:
            if not buf:
                continue
            arr = np.asarray(buf, dtype=float)
            if arr.size == 0:
                continue
            if self.detrend_var.get():
                arr = arr - np.mean(arr)
            samples.append(np.max(np.abs(arr)))
        if not samples:
            return None
        max_abs = float(max(samples))
        if max_abs <= 0.0:
            return float(presets[0])
        target = max_abs * margin
        for preset in presets:
            if target <= preset:
                return float(preset)
        return float(presets[-1])



    def _queue_waveform_refresh(self, delay: int = 250) -> None:
        if getattr(self, "_waveform_job", None) is not None:
            try:
                self.root.after_cancel(self._waveform_job)
            except Exception:
                pass
        self._waveform_job = self.root.after(delay, self._refresh_waveforms)


    def _refresh_waveforms(self) -> None:
        eeg_buffers = self.channel_buffers.get("EEG")
        self._draw_waveform(
            self.eeg_canvas,
            eeg_buffers,
            EEG_COLORS,
            self._channel_labels("EEG", len(eeg_buffers or [])),
            value_range=(-self._current_eeg_range(), self._current_eeg_range()),
        )
        self._draw_waveform(
            self.optics_canvas,
            self.channel_buffers.get("OPTICS"),
            OPTICS_COLORS,
            self._channel_labels("OPTICS", len(self.channel_buffers.get("OPTICS", []))),
            value_range=(-self._current_optics_range(), self._current_optics_range()),
        )
        self._draw_average_spectrum()
        self._queue_waveform_refresh(250)

    def _reset_spectrum(self, message: Optional[str] = None) -> None:
        self.spectrum_frames.clear()
        self.spectrum_freqs = None
        self._spectrum_window_seconds = 0.0
        if message is None:
            self._update_spectrum_status()
        elif self.spectrum_status_var is not None:
            self.spectrum_status_var.set(message)
        if hasattr(self, "spectrum_canvas"):
            canvas = self.spectrum_canvas
            canvas.delete("trace")
            width = max(canvas.winfo_width(), 320)
            height = max(canvas.winfo_height(), 220)
            canvas.create_text(
                width / 2,
                height / 2,
                text="Waiting for averaged data...",
                fill="#cccccc",
                font=("Segoe UI", 11),
                tags="trace",
            )

    def _update_spectrum_status(self) -> None:
        if self.spectrum_status_var is None:
            return
        frames = len(self.spectrum_frames)
        if frames == 0:
            self.spectrum_status_var.set("Waiting for data...")
            return
        total_seconds = frames * self._spectrum_window_seconds
        if total_seconds >= 1.0:
            self.spectrum_status_var.set(f"Averaging {frames} windows (~{total_seconds:.1f}s)")
        else:
            self.spectrum_status_var.set(f"Averaging {frames} windows")

    def _update_spectrum_data(self) -> None:
        eeg_buffers = self.channel_buffers.get("EEG")
        if not eeg_buffers:
            return
        fs = float(self.eeg_sample_rate or 256.0)
        channel_arrays: List[np.ndarray] = []
        for buf in eeg_buffers:
            arr = np.array(buf, dtype=float)
            if arr.size >= 128:
                channel_arrays.append(arr)
        if not channel_arrays:
            return
        max_fft = min(min(len(arr) for arr in channel_arrays), 1024)
        fft_power = int(math.floor(math.log2(max_fft)))
        fft_size = max(128, 1 << fft_power)
        if fft_size != self._spectrum_fft_size:
            self._spectrum_fft_size = fft_size
            self.spectrum_frames.clear()
            self.spectrum_freqs = None
        window = np.hanning(fft_size)
        step = fft_size // 2
        accum = None
        segments = 0
        for channel_data in channel_arrays:
            length = len(channel_data)
            if length < fft_size:
                continue
            for start_idx in range(0, length - fft_size + 1, step):
                segment = channel_data[start_idx:start_idx + fft_size]
                segment = segment - segment.mean()
                spectrum = np.abs(np.fft.rfft(segment * window)) ** 2
                window_energy = np.sum(window ** 2)
                psd_segment = spectrum / (fs * window_energy)
                if accum is None:
                    accum = psd_segment
                else:
                    accum += psd_segment
                segments += 1
        if segments == 0:
            return
        psd = accum / segments
        freqs = np.fft.rfftfreq(fft_size, d=1.0 / fs)
        mask = freqs <= SPECTRUM_DISPLAY_MAX_HZ
        freqs = freqs[mask]
        psd = psd[mask]
        if freqs.size == 0:
            return
        if self.spectrum_freqs is None or len(self.spectrum_freqs) != len(freqs) or not np.allclose(self.spectrum_freqs, freqs):
            self.spectrum_frames.clear()
            self.spectrum_freqs = freqs.copy()
        self.spectrum_frames.append(psd)
        self._spectrum_window_seconds = fft_size / fs
        self._update_spectrum_status()

    def _draw_average_spectrum(self) -> None:
        if not hasattr(self, "spectrum_canvas"):
            return
        canvas = self.spectrum_canvas
        canvas.delete("trace")
        frames = len(self.spectrum_frames)
        if frames == 0 or self.spectrum_freqs is None:
            width = max(canvas.winfo_width(), 320)
            height = max(canvas.winfo_height(), 220)
            canvas.create_text(
                width / 2,
                height / 2,
                text="Waiting for averaged data...",
                fill="#cccccc",
                font=("Segoe UI", 11),
                tags="trace",
            )
            return
        stacked = np.vstack(self.spectrum_frames)
        avg = stacked.mean(axis=0)
        if not np.any(avg):
            width = max(canvas.winfo_width(), 320)
            height = max(canvas.winfo_height(), 220)
            canvas.create_text(
                width / 2,
                height / 2,
                text="Spectrum unavailable",
                fill="#bbbbbb",
                font=("Segoe UI", 11),
                tags="trace",
            )
            return
        spec = avg + 1e-18
        spec_db = 10.0 * np.log10(spec)
        width = max(canvas.winfo_width(), 320)
        height = max(canvas.winfo_height(), 220)
        margin = 30
        span_x = width - 2 * margin
        span_y = height - 2 * margin
        points: List[float] = []
        max_freq = max(self.spectrum_freqs[-1], 1e-6)
        max_freq = min(max_freq, SPECTRUM_DISPLAY_MAX_HZ)
        db_max = float(np.max(spec_db))
        db_min = float(np.min(spec_db))
        if not np.isfinite(db_min) or not np.isfinite(db_max):
            return
        span_db = max(db_max - db_min, 1e-3)
        if span_db < 20.0:
            pad = (20.0 - span_db) / 2.0
            db_max += pad
            db_min -= pad
            span_db = db_max - db_min
        for freq, power in zip(self.spectrum_freqs, spec_db):
            if freq > max_freq:
                continue
            x = margin + (freq / max_freq) * span_x
            norm = (power - db_min) / span_db
            norm = max(0.0, min(1.0, norm))
            y = height - margin - norm * span_y
            points.extend((x, y))
        if points:
            canvas.create_line(points, fill="#4dabf7", width=2, tags="trace")
        tick_step = 10
        for tick in range(0, int(SPECTRUM_DISPLAY_MAX_HZ) + tick_step, tick_step):
            if tick > max_freq:
                break
            x = margin + (tick / max_freq) * span_x
            canvas.create_line(x, height - margin, x, height - margin + 6, fill="#666666", tags="trace")
            canvas.create_text(
                x,
                height - margin + 14,
                text=str(tick),
                fill="#888888",
                font=("Segoe UI", 8),
                tags="trace",
            )
        canvas.create_text(
            width - margin,
            height - margin + 24,
            anchor=tk.SE,
            text="Frequency (Hz)",
            fill="#aaaaaa",
            font=("Segoe UI", 9),
            tags="trace",
        )
        canvas.create_text(
            margin - 18,
            margin,
            anchor=tk.NW,
            text=f"Power (dB rel uV^2/Hz)\n[{db_min:.1f}, {db_max:.1f}]",
            fill="#aaaaaa",
            font=("Segoe UI", 8),
            tags="trace",
        )

    def _draw_waveform(
        self,
        canvas: tk.Canvas,
        buffers: Optional[List[Deque[float]]],
        colours: Iterable[str],
        labels: List[str],
        value_range: Optional[Tuple[float, float]] = None,
    ) -> None:
        canvas.delete("trace")
        width = max(canvas.winfo_width(), 320)
        height = max(canvas.winfo_height(), 160)
        margin = 18
        if not buffers:
            canvas.create_text(
                width / 2,
                height / 2,
                text="Waiting for data...",
                fill="#cccccc",
                font=("Segoe UI", 11),
                tags="trace",
            )
            return
        num_channels = len(buffers)
        track_height = (height - 2 * margin) / max(1, num_channels)
        for idx, (buf, colour) in enumerate(zip(buffers, colours)):
            arr = np.asarray(buf, dtype=float)
            if arr.size < 2:
                continue
            if self.detrend_var.get():
                arr = arr - np.mean(arr)
            if value_range is not None:
                v_min, v_max = value_range
                if math.isclose(v_min, v_max, rel_tol=1e-6, abs_tol=1e-6):
                    v_max = v_min + 1.0
                arr = np.clip(arr, v_min, v_max)
            else:
                v_min = float(np.min(arr))
                v_max = float(np.max(arr))
                if math.isclose(v_min, v_max, rel_tol=1e-6, abs_tol=1e-6):
                    v_max = v_min + 1.0
            plot_values = arr.tolist()
            if len(plot_values) < 2:
                continue
            denom = v_max - v_min
            if math.isclose(denom, 0.0, rel_tol=1e-6, abs_tol=1e-6):
                denom = 1.0
            points: List[float] = []
            base_y = margin + idx * track_height
            span_x = max(1.0, width - 2 * margin)
            span_y = max(1.0, track_height - 14)
            for pos, value in enumerate(plot_values):
                x = margin + (pos / (len(plot_values) - 1)) * span_x
                norm = (value - v_min) / denom
                norm = max(0.0, min(1.0, norm))
                y = base_y + track_height - norm * span_y
                points.extend((x, y))
            canvas.create_line(points, fill=colour, width=2, tags="trace")
            label = labels[idx] if idx < len(labels) else f"Ch{idx + 1}"
            canvas.create_text(
                margin + 4,
                base_y + 4,
                anchor=tk.NW,
                fill=colour,
                font=("Segoe UI", 9, "bold"),
                text=label,
                tags="trace",
            )








def main() -> None:
    root = tk.Tk()
    app = MuseApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()

